# Fix A2P 10DLC Rejection — Step by Step
## The Property Father | February 14, 2026

---

## WHY IT WAS REJECTED

The A2P verification bot crawls your website as raw HTML — it does NOT run JavaScript.
Your site is a React SPA, so the bot sees this:

```html
<div id="root"></div>
```

That's it. No form, no consent language, no terms page, no privacy page. Blank.

Two rejection reasons:
1. **"Unverifiable website"** — Bot couldn't find the opt-in form or consent language
2. **"CTA verification failed"** — Bot couldn't verify the Call to Action described in your campaign

---

## THE FIX (3 files + 1 edit)

You're adding 3 static HTML files to Replit and making 1 edit to index.html.
Total time: ~10 minutes.

---

## STEP 1: Add terms.html to Replit

1. Open the Property Father project in Replit
2. In the file tree, find the **public** folder
3. Right-click > **New File** > name it **terms.html**
4. Open the **terms.html** file I gave you
5. Copy the ENTIRE contents and paste into Replit
6. Save

**Verify:** After deploy, visit https://thepropertyfather.com/terms.html
You should see a fully rendered Terms of Service page (no JavaScript needed).

---

## STEP 2: Add privacy.html to Replit

1. Same thing — in the **public** folder
2. Right-click > **New File** > name it **privacy.html**
3. Open the **privacy.html** file I gave you
4. Copy the ENTIRE contents and paste into Replit
5. Save

**Verify:** After deploy, visit https://thepropertyfather.com/privacy.html
You should see a fully rendered Privacy Policy page.

---

## STEP 3: Add noscript block to index.html

1. Open **index.html** in Replit (this is in the root or public folder)
2. Find this line:

```html
<div id="root"></div>
```

3. Paste the noscript block DIRECTLY AFTER that line, so it looks like:

```html
<div id="root"></div>

<!-- A2P Compliance: Static content for verification bots that don't execute JavaScript -->
<noscript>
  <div style="font-family: sans-serif; max-width: 800px; margin: 40px auto; padding: 20px;">
    <h1>The Property Father | We Buy Houses for Cash on Long Island</h1>
    <p>The Property Father LLC buys houses in any condition in Suffolk County and Nassau County, New York. No fees, no repairs, close in as few as 7 days.</p>
    <p>Phone: (516) 548-6558 | Email: info@thepropertyfather.com</p>
    <p>100 Washington Ave, Patchogue, NY 11772</p>

    <h2>Get Your Free Cash Offer</h2>
    <p>Fill out our form to receive a no-obligation cash offer on your Long Island property. We collect your name, phone number, email address, and property address to evaluate your home and contact you with an offer.</p>

    <h3>SMS/Text Message Consent</h3>
    <p>By submitting the form on this website and checking the SMS consent checkbox, you consent to receive marketing and non-marketing text messages from The Property Father LLC at the phone number provided. Message frequency may vary. Message and data rates may apply. Text HELP for assistance. Reply STOP to opt out at any time. Your consent to receive text messages is not a condition of purchase.</p>

    <p><a href="/terms.html">Terms of Service</a> | <a href="/privacy.html">Privacy Policy</a></p>
  </div>
</noscript>
```

4. Save
5. **Deploy** the site

**Note:** Normal visitors will NOT see this block — it only appears when JavaScript is disabled (which is how the bot crawls). Your site looks exactly the same to real users.

---

## STEP 4: Verify everything works

Before you re-submit, test all three URLs:

1. https://thepropertyfather.com/terms.html — Should show Terms of Service
2. https://thepropertyfather.com/privacy.html — Should show Privacy Policy
3. https://thepropertyfather.com — Right-click > View Page Source > Search for "SMS" — you should see the consent language in the noscript block

---

## STEP 5: Update the A2P campaign in GHL and re-submit

1. Go to **Settings > Phone System > Trust Center**
2. Click **Re-Submit** on the A2P campaign
3. Update these fields:

**Opt-In Form URL:** Change to:
```
https://thepropertyfather.com
```

**"How do Contacts Opt-in" description — use this exact text:**
```
End users opt-in by visiting https://thepropertyfather.com and completing the "Get a Cash Offer" form. The form collects name, phone, email, and property address. Users must check an SMS consent checkbox that states: "I consent to receive marketing text messages from The Property Father at the phone number provided. Frequency may vary. Message & data rates may apply. Text HELP for assistance, reply STOP to opt out." Only users who check the consent box and submit the form receive SMS communications. The website's Terms of Service (https://thepropertyfather.com/terms.html) and Privacy Policy (https://thepropertyfather.com/privacy.html) are linked on all forms and accessible to users.
```

4. Make sure the **sample messages** still include "Reply STOP to unsubscribe" or "Reply STOP to opt out"
5. Submit

---

## STEP 6: Confirm SMS consent checkbox is on the live form

This is critical — the React form on the site needs an actual checkbox. Check that the contact form currently has:

☐ I consent to receive marketing text messages from The Property Father at the phone number provided. Frequency may vary. Message & data rates may apply. Text HELP for assistance, reply STOP to opt out.

If it's missing, add it to the React component. The checkbox must be **required** (form won't submit without it).

---

## TIMELINE

- Steps 1-4: Do today (~10 min in Replit)
- Step 5: Re-submit today after verifying
- Approval: 1-7 business days

---

## ALSO: Update React Router Links

Your React app currently routes /terms and /privacy through the SPA router.
You should update the footer links in your React components to point to:

- /terms.html (instead of /terms)
- /privacy.html (instead of /privacy)

This ensures both the bot AND real users land on the static pages.

---
